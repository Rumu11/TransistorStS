package theDefault.util;

public class IDCheckDontTouchPls {
    public String DEFAULTID;
    public String DEVID;
    public String EXCEPTION;
    public String PACKAGE_EXCEPTION;
    public String RESOURCE_FOLDER_EXCEPTION;
    public String RESOURCES;
}
